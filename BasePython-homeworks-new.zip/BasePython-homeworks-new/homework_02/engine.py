"""
create dataclass `Engine`
"""
