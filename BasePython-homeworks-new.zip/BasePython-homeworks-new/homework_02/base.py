from abc import ABC


class Vehicle(ABC):
    pass
